package com.company;

import java.util.List;

public class Modif_atributes implements  Modifier{

    private String ime_har_voinik;
    private int stoinost;


    @Override
    public int Modify(Voinik voinik, Voinik protivnik) {

        return 0;
    }

    Modif_atributes(String ime_har_voinik, int stoinost)
    {
        this.ime_har_voinik = ime_har_voinik;
        this.stoinost = stoinost;
    }


}

package com.company;

import java.util.List;

public class Modif_atk implements Modifier{

    private String ime_tag_enemy;
    private int stoinost;

    public int getStoinost() {
        return stoinost;
    }

    Modif_atk(String ime_tag_enemy, int stoinost)
    {
        this.ime_tag_enemy = ime_tag_enemy;
        this.stoinost = stoinost;
    }

    @Override
    public int Modify(Voinik voinik, Voinik protivnik) {

        voinik.sila_atk += stoinost;

        for(String i : protivnik.tagove)
        {
            if (i == "Archer")
            {
                int stoinost = this.stoinost;
                return stoinost;
            }
        }
        return 0;

    }

}

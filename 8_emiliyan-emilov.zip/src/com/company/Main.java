package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Voinik solder = new Voinik("Bob", 100, 10, 5, 15, "Range");
        Voinik solder2 = new Voinik("Pol", 110, 10, 15, 25, "Range");
        Voinik solder3 = new Voinik("Jo", 120, 20, 25, 35, "Range");

        System.out.println(solder.toString());

        Modif_atk modifikator = new Modif_atk("Archer", 10);
        modifikator.Modify(solder, solder2);

        System.out.println(solder.toString());

        List<Voinik> enemies = new ArrayList<>();
        enemies.add(solder2);
        enemies.add(solder3);

        System.out.println(solder.chooseTarget(enemies));

        System.out.println(solder.getDamageAgainst(solder2, 10, "Range", solder));

        System.out.println(solder.getDamageFrom(solder2, 20, "Range", solder));

        solder.receiveAttack(solder2, 70, "Range", solder);
        System.out.println(solder.toString());

    }
}

package com.company;

import java.util.ArrayList;
import java.util.List;

public class Voinik {

    private String name;
    private String  vid_atk;
    private int tekysht_health;
    private int max_health;
    int sila_atk;
    int zashtita_mele;
    int zashtita_range;
    ArrayList<String> tagove = new ArrayList<>();
    ArrayList<Modifier> modificatori = new ArrayList<>();


    Voinik(String name, int max_health, int sila_atk, int zashtita_mele, int zashtita_range, String vid_atk)
    {
        this.name = name;
        this.max_health = max_health;
        this.tekysht_health = max_health;
        this.sila_atk = sila_atk;
        this.zashtita_mele = zashtita_mele;
        this.zashtita_range = zashtita_range;
        this.vid_atk = vid_atk;
    }
    public int GetDefM()
    {
        return zashtita_mele;
    }

    void addModifier(Modif_def mod)
    {
            modificatori.add(mod);

    }
    void addModifier(Modif_atk mod)
    {
        modificatori.add(mod);
    }
    void addModifier(Modif_atributes mod)
    {
        modificatori.add(mod);
    }


    public int Get_tekysht_health()
    {
        return tekysht_health;
    }

    public int Get_max_health( )
    {
        return max_health;
    }

    public int Get_sila_atk(Voinik solder)
    {
        int sum = solder.sila_atk;
        for(Modifier i : modificatori)
        {
            if(i instanceof Modif_atk)
            {
                sum = sum + ((Modif_atk) i).getStoinost();
            }
        }
        return sum ;
    }

    public int Get_zashtita_mele(Voinik solder)
    {
        int sum = solder.zashtita_mele;
        for(Modifier i : modificatori)
        {
            if(i instanceof Modif_def)
            {
                sum = sum + ((Modif_def) i).getStoinost();
            }
        }
        return sum ;
    }

    public int Get_zashtita_range(Voinik solder)
    {
        int sum = solder.zashtita_range;
        for(Modifier i : modificatori)
        {
            if(i instanceof Modif_def)
            {
                sum = sum + ((Modif_def) i).getStoinost();
            }
        }
        return sum ;
    }

    public String toString() {

        int sum_def_mele = 0;
        int sum_def_range = 0;
        int sum_atk = 0;

        for(Modifier i : modificatori)
        {
            if(i instanceof Modif_def)
            {
                sum_def_mele = sum_def_mele + ((Modif_def) i).getStoinost();
                sum_def_range = sum_def_range + ((Modif_def) i).getStoinost();

            }
            if(i instanceof Modif_atk)
            {
                sum_atk = sum_atk + ((Modif_atk) i).getStoinost();
            }
        }

        return this.name + " \n" +
                "   HP: " + this.tekysht_health + "/" + this.max_health + "\n" +
                "   ATK: " + this.sila_atk + " + " + ( this.Get_sila_atk(this) - this.sila_atk) + "\n" +
                "   DEF: " + this.zashtita_mele + " + " + ( this.Get_zashtita_mele(this) - this.zashtita_mele) + "/" + this.zashtita_range + ( this.Get_zashtita_range(this) - this.zashtita_range) + "\n" +
                "Modifiers:\n" +
                "Extra attack:" + " +" + sum_atk + "\n" +
                "Extra def_mele:" + " +" + sum_def_mele + "\n" +
                "Extra def_range:" + " +" + sum_def_range + "\n";
    }


    Voinik chooseTarget(List<Voinik> enemies)
    {
        Voinik optimalen = enemies.get(0);
        for(Voinik i : enemies)
        {
            if( getDamageAgainst(i, i.sila_atk, i.vid_atk, optimalen)  < getDamageAgainst(optimalen, optimalen.sila_atk, optimalen.vid_atk, i) )
            {
                optimalen = i;
            }
        }
        return optimalen;
    }

    int getDamageAgainst(  Voinik enemy, int value, String type, Voinik voin)
    {
        if(enemy.vid_atk == "Range")// enemy e archer
        {
            int sum = voin.sila_atk;
            for(Modifier i : modificatori)
            {
                if(i instanceof Modif_atk)
                {
                    sum = sum + ((Modif_atk) i).getStoinost();
                }
            }
            return sum ;
        }
        if(enemy.vid_atk == "Melee")// enemy e mele
        {
            int sum = voin.sila_atk;
            for(Modifier i : modificatori)
            {
                if(i instanceof Modif_atk)
                {
                    sum = sum + ((Modif_atk) i).getStoinost();
                }
            }
            return sum ;
        }
        System.out.println("neshto greshno e stanalo");
        return 0;
    }

    int getDamageFrom(Voinik enemy, int value, String type, Voinik voinche)
    {
        if(type == "Range")// enemy e archer
        {
            int sum_def = voinche.zashtita_range;
            for(Modifier i : modificatori)
            {
                if(i instanceof Modif_def)
                {
                    sum_def = sum_def + ((Modif_def) i).getStoinost();
                }
            }
            if( sum_def > value)
            {
                return 1;
            }
            if(value > sum_def)
            {
                return value - sum_def;
            }
            return 1;
        }
        if(type == "Melee")// enemy e mele
        {
            int sum_def = voinche.zashtita_mele;
            for(Modifier i : modificatori)
            {
                if(i instanceof Modif_def)
                {
                    sum_def = sum_def + ((Modif_def) i).getStoinost();
                }
            }
            if( sum_def > value)
            {
                return 1;
            }
            if(value > sum_def)
            {
                return value - sum_def;
            }
            return 1;
        }
        System.out.println("neshto greshno e stanalo");
        return 0;
    }

    void receiveAttack(Voinik enemy, int value, String type, Voinik solder)
    {
        solder.tekysht_health -= getDamageAgainst(enemy, value, type, solder);

    }
}

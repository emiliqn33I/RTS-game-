package com.company;

import java.util.List;

public interface Modifier {

    int Modify(Voinik vonik, Voinik protivnik);

}
